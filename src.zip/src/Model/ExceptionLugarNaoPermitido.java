package Model;

public class ExceptionLugarNaoPermitido extends Exception {
	ExceptionLugarNaoPermitido(String msg) {
		super(msg);
	}
}
