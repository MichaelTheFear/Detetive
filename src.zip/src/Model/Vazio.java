package Model;

public class Vazio extends Posicao{

	Vazio(int linha, int coluna) {
		super(linha, coluna);
	}

}
