package Util;

public enum Armas {
	Cano,
	Castical,
	ChaveInglesa,
	Corda,
	Faca,
	Revolver
}
