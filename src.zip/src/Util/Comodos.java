package Util;

public enum Comodos {
	Biblioteca,
	Cozinha,
	Entrada,
	Escritorio,
	JardimInverno,
	SalaDeEstar,
	SalaDeJantar,
	SalaDeMusica,
	SalaoDeJogos
}
