package Util;

public enum Events {
	boardClick,
	dice,
	showCards,
	showNotes,
	showAccuse,
	confirmGuess,
	confirmAccuse,
}
