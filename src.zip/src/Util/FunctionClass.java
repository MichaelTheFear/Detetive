package Util;

public class FunctionClass {
	public void callbackVoid(){
		
	}
	
	public void callbackVoid(String name) {
		
	}
	
	public String callbackString() {
		return "Error";
	}
	
}
