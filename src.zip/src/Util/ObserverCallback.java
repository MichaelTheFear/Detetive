package Util;

public interface ObserverCallback {
	void onCall(Object o);
}
