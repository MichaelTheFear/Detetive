package Util;

public enum Personagem {
	Scarlet,
	Mustard,
	White,
	Green,
	Peacock,
	Plum
}
