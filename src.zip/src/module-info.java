/**
 * 
 */
/**
 * @author eduda
 *
 */
module Detetive {
	requires junit;
	requires java.desktop;
}